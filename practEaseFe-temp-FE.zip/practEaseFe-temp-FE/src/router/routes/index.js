// Common export

import { PrivateRoutes } from "./privateRoutes"
import { PublicRoutes } from "./publicRoutes"

export { PrivateRoutes, PublicRoutes }
