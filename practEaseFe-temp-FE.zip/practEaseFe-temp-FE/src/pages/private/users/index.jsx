import React from "react"
import { Divider } from "@mui/material"

function Users() {
  return (
    <div>
      <h2>Users</h2>
      <Divider />
    </div>
  )
}

export default Users
