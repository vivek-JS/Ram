import React from "react"
import { Divider } from "@mui/material"

function SubAdmins() {
  return (
    <div>
      <h2>Sub Admins</h2>
      <Divider />
    </div>
  )
}

export default SubAdmins
