export const GENDERS = {
  MALE: "Male",
  FEMALE: "Female",
  OTHER: "Others"
}
