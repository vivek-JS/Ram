export const OFFLINE = {
  LOGIN: require("./files/login.json"),
  SIGNUP: require("./files/signup.json"),
  FORGOTPASSWORD: require("./files/forgot-password.json"),
  RESETPASSWORD: require("./files/reset-password.json"),
  LOGINGOOGLE: require("./files/login.json"),
  LOGINFACEBOOK: require("./files/login.json"),
  LOGOUT: require("./files/logout.json"),
  PROFILE: require("./files/profile.json")
}
