export const fieldsConfig = ["openid", "profile", "email"]
